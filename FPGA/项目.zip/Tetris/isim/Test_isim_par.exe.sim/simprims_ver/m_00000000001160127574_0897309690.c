/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001160127574_0897309690_2150623255_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2150623255", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2150623255.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1549444494_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1549444494", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1549444494.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3939927884_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3939927884", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3939927884.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2143117172_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2143117172", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2143117172.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3307531389_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3307531389", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3307531389.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0706300317_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0706300317", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0706300317.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0727210124_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0727210124", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0727210124.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3345204755_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3345204755", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3345204755.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0677274611_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0677274611", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0677274611.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0760491634_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0760491634", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0760491634.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1903414051_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1903414051", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1903414051.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0116201939_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0116201939", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0116201939.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2638763452_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2638763452", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2638763452.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3922770995_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3922770995", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3922770995.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1920331868_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1920331868", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1920331868.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0099295916_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0099295916", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0099295916.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3973771698_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3973771698", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3973771698.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2004860381_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2004860381", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2004860381.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3236669872_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3236669872", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3236669872.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0751843119_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0751843119", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0751843119.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0031796378_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0031796378", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0031796378.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2651536485_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2651536485", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2651536485.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1915790074_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1915790074", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1915790074.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2634876698_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2634876698", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2634876698.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1899403653_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1899403653", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1899403653.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0060950260_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0060950260", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0060950260.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2550614683_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2550614683", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2550614683.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3290476490_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3290476490", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3290476490.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1602610085_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1602610085", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1602610085.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0672870741_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0672870741", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0672870741.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3015605562_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3015605562", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3015605562.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3341194421_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3341194421", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3341194421.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1552144602_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1552144602", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1552144602.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0723323434_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0723323434", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0723323434.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2964866629_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2964866629", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2964866629.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3257719092_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3257719092", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3257719092.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2592434361_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2592434361", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2592434361.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3994911030_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3994911030", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3994911030.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1975045465_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1975045465", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1975045465.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2575520710_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2575520710", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2575520710.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1890746584_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1890746584", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1890746584.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3073386982_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3073386982", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3073386982.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3914996095_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3914996095", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3914996095.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1929336080_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1929336080", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1929336080.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3977332207_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3977332207", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3977332207.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2593101599_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2593101599", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2593101599.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1974612735_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1974612735", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1974612735.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3994517136_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3994517136", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3994517136.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2575936608_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2575936608", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2575936608.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0036495375_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0036495375", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0036495375.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1891139454_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1891139454", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1891139454.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3074086464_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3074086464", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3074086464.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0748657199_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0748657199", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0748657199.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1526810847_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1526810847", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1526810847.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3231974576_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3231974576", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3231974576.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3023891775_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3023891775", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3023891775.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0798597456_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0798597456", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0798597456.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1476883360_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1476883360", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1476883360.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3282190287_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3282190287", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3282190287.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2973147326_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2973147326", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2973147326.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2650915779_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2650915779", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2650915779.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0094670764_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0094670764", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0094670764.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1916427612_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1916427612", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1916427612.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0061405522_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0061405522", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0061405522.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3014951580_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3014951580", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3014951580.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0672255731_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0672255731", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0672255731.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3349950969_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3349950969", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3349950969.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1544125846_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1544125846", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1544125846.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1531189881_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1531189881", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1531189881.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3235993110_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3235993110", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3235993110.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1582192632_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1582192632", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1582192632.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3320519575_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3320519575", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3320519575.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2580348614_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2580348614", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2580348614.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0040481449_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0040481449", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0040481449.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3998362678_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3998362678", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3998362678.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2596980153_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2596980153", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2596980153.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0024086998_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0024086998", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0024086998.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2680195128_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2680195128", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2680195128.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0726837034_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0726837034", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0726837034.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3295609546_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3295609546", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3295609546.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1903768709_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1903768709", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1903768709.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3940317418_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3940317418", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3940317418.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2638391834_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2638391834", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2638391834.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0115861109_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0115861109", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0115861109.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2496374276_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2496374276", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2496374276.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3826783003_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3826783003", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3826783003.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2525793386_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2525793386", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2525793386.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0220839941_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0220839941", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0220839941.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1359881556_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1359881556", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1359881556.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3400231227_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3400231227", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3400231227.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3174415307_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3174415307", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3174415307.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0647034788_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0647034788", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0647034788.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1376263723_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1376263723", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1376263723.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3383579204_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3383579204", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3383579204.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1459770282_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1459770282", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1459770282.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3767945159_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3767945159", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3767945159.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2533922103_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2533922103", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2533922103.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0572433272_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0572433272", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0572433272.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1434481032_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1434481032", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1434481032.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0045101092_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0045101092", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0045101092.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1167872090_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1167872090", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1167872090.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2550827487_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2550827487", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2550827487.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0140371084_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0140371084", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0140371084.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3586866441_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3586866441", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3586866441.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0839025322_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0839025322", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0839025322.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4087618984_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4087618984", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4087618984.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0775078957_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0775078957", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0775078957.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2482546915_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2482546915", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2482546915.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1315860838_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1315860838", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1315860838.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0857569086_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0857569086", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0857569086.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4002131643_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4002131643", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4002131643.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1396818549_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1396818549", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1396818549.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1199939249_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1199939249", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1199939249.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2584954676_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2584954676", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2584954676.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0668543994_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0668543994", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0668543994.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4199543423_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4199543423", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4199543423.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3711903562_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3711903562", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3711903562.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0011140815_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0011140815", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0011140815.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3239010765_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3239010765", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3239010765.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2093288707_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2093288707", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2093288707.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2706625670_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2706625670", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2706625670.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3162269589_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3162269589", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3162269589.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3063001917_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3063001917", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3063001917.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1708628299_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1708628299", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1708628299.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2313947092_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2313947092", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2313947092.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0306793403_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0306793403", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0306793403.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1910190825_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1910190825", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1910190825.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0922178199_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0922178199", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0922178199.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4149333397_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4149333397", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4149333397.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0717689872_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0717689872", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0717689872.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2534242526_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2534242526", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2534242526.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3934158470_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3934158470", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3934158470.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1471418952_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1471418952", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1471418952.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1891944317_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1891944317", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1891944317.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0590150599_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0590150599", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0590150599.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3653957495_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3653957495", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3653957495.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0073150194_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0073150194", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0073150194.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0409757813_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0409757813", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0409757813.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2016468286_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2016468286", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2016468286.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2779120827_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2779120827", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2779120827.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0088333158_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0088333158", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0088333158.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1758062860_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1758062860", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1758062860.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1795630357_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1795630357", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1795630357.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2093302446_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2093302446", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2093302446.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3238997600_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3238997600", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3238997600.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0479852517_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0479852517", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0479852517.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1005134544_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1005134544", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1005134544.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3867147093_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3867147093", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3867147093.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4199529938_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4199529938", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4199529938.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0668558423_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0668558423", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0668558423.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2584938649_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2584938649", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2584938649.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1199952156_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1199952156", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1199952156.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0989255492_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0989255492", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0989255492.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3881832129_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3881832129", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3881832129.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1521115663_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1521115663", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1521115663.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2268904330_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2268904330", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2268904330.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0775064448_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0775064448", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0775064448.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4087632389_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4087632389", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4087632389.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3570698032_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3570698032", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3570698032.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0155344565_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0155344565", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0155344565.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0359798834_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0359798834", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0359798834.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3370434999_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3370434999", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3370434999.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2830660860_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2830660860", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2830660860.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3586880164_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3586880164", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3586880164.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4069734623_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4069734623", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4069734623.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0310506352_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0310506352", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0310506352.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1696539008_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1696539008", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1696539008.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3800705896_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3800705896", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3800705896.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0590132330_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0590132330", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0590132330.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3818249980_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3818249980", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3818249980.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2211015607_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2211015607", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2211015607.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0717708221_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0717708221", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0717708221.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4149314104_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4149314104", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4149314104.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3491845901_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3491845901", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3491845901.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0230133384_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0230133384", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0230133384.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3423670666_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3423670666", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3423670666.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1910209860_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1910209860", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1910209860.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0107864077_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0107864077", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0107864077.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1928661378_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1928661378", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1928661378.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0206095299_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0206095299", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0206095299.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3323756029_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3323756029", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3323756029.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3144645541_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3144645541", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3144645541.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1727636000_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1727636000", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1727636000.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0567657054_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0567657054", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0567657054.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4232256475_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4232256475", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4232256475.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1572417938_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1572417938", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1572417938.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4250725967_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4250725967", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4250725967.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1083605633_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1083605633", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1083605633.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2634046212_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2634046212", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2634046212.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3127938609_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3127938609", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3127938609.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1743148980_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1743148980", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1743148980.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2498475219_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2498475219", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2498475219.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0690083869_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0690083869", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0690083869.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2311325632_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2311325632", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2311325632.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0873360142_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0873360142", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0873360142.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3919098507_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3919098507", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3919098507.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3471337406_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3471337406", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3471337406.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0327073339_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0327073339", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0327073339.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3537379641_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3537379641", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3537379641.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1863470583_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1863470583", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1863470583.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2947229537_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2947229537", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2947229537.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3029658412_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3029658412", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3029658412.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3321918557_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3321918557", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3321918557.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0638762994_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0638762994", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0638762994.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4219758199_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4219758199", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4219758199.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2436171668_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2436171668", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2436171668.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1285807633_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1285807633", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1285807633.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4050236127_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4050236127", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4050236127.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0754936666_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0754936666", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0754936666.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0193969775_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0193969775", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0193969775.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3591989226_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3591989226", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3591989226.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3391693165_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3391693165", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3391693165.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0398457064_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0398457064", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0398457064.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2859832358_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2859832358", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2859832358.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2011385251_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2011385251", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2011385251.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0177228795_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0177228795", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0177228795.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3076138805_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3076138805", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3076138805.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1304177541_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1304177541", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1304177541.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1663504743_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1663504743", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1663504743.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2745072625_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2745072625", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2745072625.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0508827455_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0508827455", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0508827455.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3284324026_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3284324026", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3284324026.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3836877711_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3836877711", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3836877711.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0622101645_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0622101645", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0622101645.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4169293064_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4169293064", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4169293064.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2564745283_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2564745283", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2564745283.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3853381147_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3853381147", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3853381147.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3355437537_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3355437537", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3355437537.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2959162129_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2959162129", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2959162129.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1070128348_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1070128348", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1070128348.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4120666850_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4120666850", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4120666850.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0671791975_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0671791975", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0671791975.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0259681874_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0259681874", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0259681874.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3538728919_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3538728919", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3538728919.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3470586192_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3470586192", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3470586192.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0323627221_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0323627221", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0323627221.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2927641627_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2927641627", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2927641627.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1930861982_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1930861982", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1930861982.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0241540038_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0241540038", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0241540038.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3555934787_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3555934787", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3555934787.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1849241229_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1849241229", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1849241229.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3014653704_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3014653704", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3014653704.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1229585336_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1229585336", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1229585336.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1741865306_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1741865306", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1741865306.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3659050388_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3659050388", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3659050388.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0126776337_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0126776337", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0126776337.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0446809858_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0446809858", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0446809858.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3762801586_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3762801586", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3762801586.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1037111863_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1037111863", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1037111863.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1414436936_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1414436936", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1414436936.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3853361590_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3853361590", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3853361590.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2564728814_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2564728814", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2564728814.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4169274021_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4169274021", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4169274021.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0622119712_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0622119712", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0622119712.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0040115733_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0040115733", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0040115733.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3757229968_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3757229968", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3757229968.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3284304151_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3284304151", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3284304151.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0508844178_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0508844178", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0508844178.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2745054300_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2745054300", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2745054300.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2114514393_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2114514393", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2114514393.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0058452865_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0058452865", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0058452865.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3740086788_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3740086788", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3740086788.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1663524554_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1663524554", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1663524554.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3199305551_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3199305551", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3199305551.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2579583610_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2579583610", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2579583610.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1146588159_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1146588159", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1146588159.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1791799581_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1791799581", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1791799581.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3607551443_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3607551443", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3607551443.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0177210454_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0177210454", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0177210454.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2011365902_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2011365902", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2011365902.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2859850635_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2859850635", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2859850635.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0818897520_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0818897520", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0818897520.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0754918647_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0754918647", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0754918647.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2436188217_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2436188217", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2436188217.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0835753956_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0835753956", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0835753956.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0908295334_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0908295334", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0908295334.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4235707032_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4235707032", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4235707032.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0110218792_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0110218792", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0110218792.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3674675117_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3674675117", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3674675117.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3342291242_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3342291242", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3342291242.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0446793903_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0446793903", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0446793903.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2808865889_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2808865889", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2808865889.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2063416804_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2063416804", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2063416804.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0126761916_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0126761916", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0126761916.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3659063865_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3659063865", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3659063865.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1741852407_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1741852407", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1741852407.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3125041010_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3125041010", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3125041010.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1084382146_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1084382146", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1084382146.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3014637733_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3014637733", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3014637733.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1849254176_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1849254176", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1849254176.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3555921390_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3555921390", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3555921390.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1930875443_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1930875443", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1930875443.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2927627190_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2927627190", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2927627190.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0323643256_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0323643256", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0323643256.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3470573309_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3470573309", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3470573309.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3920391112_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3920391112", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3920391112.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0876261965_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0876261965", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0876261965.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0891635673_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0891635673", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0891635673.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1021765559_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1021765559", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1021765559.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2991650286_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2991650286", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2991650286.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1113271798_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1113271798", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1113271798.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0570923197_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0570923197", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0570923197.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2195867488_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2195867488", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2195867488.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1601478373_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1601478373", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1601478373.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3804164651_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3804164651", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3804164651.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0408485531_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0408485531", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0408485531.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3318621982_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3318621982", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3318621982.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3657327001_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3657327001", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3657327001.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0073971740_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0073971740", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0073971740.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3114456274_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3114456274", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3114456274.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1681132887_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1681132887", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1681132887.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2031861316_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2031861316", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2031861316.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2760730561_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2760730561", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2760730561.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2214441716_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2214441716", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2214441716.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1584098161_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1584098161", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1584098161.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3443146077_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3443146077", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3443146077.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0279766232_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0279766232", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0279766232.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1843389056_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1843389056", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1843389056.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1453289778_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1453289778", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1453289778.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2699674640_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2699674640", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2699674640.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4215084431_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4215084431", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4215084431.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2253263831_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2253263831", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2253263831.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3859981980_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3859981980", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3859981980.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0998539033_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0998539033", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0998539033.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0485796396_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0485796396", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0485796396.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3244454825_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3244454825", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3244454825.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3713152302_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3713152302", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3713152302.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0012905643_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0012905643", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0012905643.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3171844197_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3171844197", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3171844197.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1620597216_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1620597216", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1620597216.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3229451837_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3229451837", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3229451837.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2109205235_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2109205235", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2109205235.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2270291523_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2270291523", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2270291523.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1523007430_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1523007430", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1523007430.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1952187684_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1952187684", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1952187684.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3382077930_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3382077930", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3382077930.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0335589487_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0335589487", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0335589487.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1769190967_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1769190967", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1769190967.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4090040268_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4090040268", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4090040268.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1872734433_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1872734433", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1872734433.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3806820001_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3806820001", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3806820001.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1064415012_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1064415012", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1064415012.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0402749969_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0402749969", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0402749969.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3651659027_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3651659027", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3651659027.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0070335638_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0070335638", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0070335638.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3120255064_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3120255064", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3120255064.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0421433221_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0421433221", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0421433221.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0232444737_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0232444737", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0232444737.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0715785844_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0715785844", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0715785844.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1455879608_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1455879608", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1455879608.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_4026074854_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_4026074854", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_4026074854.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0846192483_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0846192483", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0846192483.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3364475859_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3364475859", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3364475859.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3034914847_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3034914847", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3034914847.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3859999025_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3859999025", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3859999025.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2176694072_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2176694072", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2176694072.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0300604011_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0300604011", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0300604011.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1701983204_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1701983204", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1701983204.didat");
}
