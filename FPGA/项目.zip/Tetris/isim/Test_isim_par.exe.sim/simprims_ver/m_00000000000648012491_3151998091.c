/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_0300137519_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0300137519", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0300137519.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0537634482_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0537634482", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0537634482.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0488572414_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0488572414", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0488572414.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3144158794_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3144158794", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3144158794.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1293975203_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1293975203", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1293975203.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3561259681_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3561259681", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3561259681.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3853293628_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3853293628", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3853293628.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1138463624_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1138463624", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1138463624.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3079976859_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3079976859", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3079976859.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1915980053_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1915980053", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1915980053.didat");
}
