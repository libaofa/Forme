/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000003620161072_1069848932_init();
    work_m_00000000004291252969_2907810454_init();
    work_m_00000000004132821705_2582214024_init();
    work_m_00000000001250256495_2246955934_init();
    work_m_00000000001068021678_0286164271_init();
    work_m_00000000002816130603_2989001185_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002816130603_2989001185");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
