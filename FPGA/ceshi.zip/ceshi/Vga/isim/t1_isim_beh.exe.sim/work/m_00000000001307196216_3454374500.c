/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Ken/Desktop/ceshi/Word.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {0U, 0U, 4194304U, 0U, 0U, 0U, 96U, 0U, 0U, 0U, 268435456U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 134217728U, 0U, 0U, 0U};
static int ng5[] = {2, 0};
static unsigned int ng6[] = {6291456U, 0U, 6291456U, 0U, 0U, 0U, 48U, 0U, 2097152U, 0U, 402653184U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 256U, 0U, 4197376U, 0U, 25165824U, 0U, 7U, 0U, 12288U, 0U, 24576U, 0U, 471334912U, 0U, 0U, 0U};
static int ng7[] = {3, 0};
static unsigned int ng8[] = {3670016U, 0U, 7340032U, 0U, 4U, 0U, 1610612764U, 0U, 3670016U, 0U, 503316528U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 192U, 0U, 1080037120U, 0U, 14680064U, 0U, 3145731U, 0U, 14336U, 0U, 12288U, 0U, 470548480U, 0U, 0U, 0U};
static int ng9[] = {4, 0};
static unsigned int ng10[] = {1835008U, 0U, 14680064U, 0U, 14U, 0U, 4026531868U, 0U, 1835009U, 0U, 939524144U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 202113248U, 0U, 1613762048U, 0U, 12591104U, 0U, 4294443011U, 0U, 12799U, 0U, 14336U, 0U, 403570688U, 0U, 0U, 0U};
static int ng11[] = {5, 0};
static unsigned int ng12[] = {1835008U, 0U, 13631488U, 0U, 8190U, 0U, 3758096398U, 0U, 1843599U, 0U, 1056964656U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 196608U, 0U, 0U, 0U, 0U, 0U, 268304480U, 0U, 808983552U, 0U, 12611584U, 0U, 1610612739U, 0U, 12480U, 0U, 7168U, 0U, 939917312U, 0U, 0U, 0U};
static int ng13[] = {6, 0};
static unsigned int ng14[] = {524320U, 0U, 30408706U, 0U, 12U, 0U, 12U, 0U, 553456U, 0U, 1908408368U, 0U, 1017856U, 0U, 528515064U, 0U, 129152U, 0U, 0U, 0U, 805306368U, 0U, 16711680U, 0U, 4043046960U, 0U, 536870919U, 0U, 203178080U, 0U, 943200256U, 0U, 4294965248U, 0U, 1610629119U, 0U, 12288U, 0U, 7168U, 0U, 805568704U, 0U, 0U, 0U};
static int ng15[] = {7, 0};
static unsigned int ng16[] = {96U, 0U, 25690114U, 0U, 2097164U, 0U, 131084U, 0U, 536869312U, 0U, 1893728304U, 0U, 3700736U, 0U, 817896462U, 0U, 397184U, 0U, 0U, 0U, 2013265920U, 0U, 458752U, 0U, 3224371320U, 0U, 1879048193U, 0U, 202915904U, 0U, 471603200U, 0U, 12582912U, 0U, 1610619907U, 0U, 798720U, 0U, 6144U, 0U, 2147483616U, 0U, 0U, 0U};
static int ng17[] = {8, 0};
static unsigned int ng18[] = {4294967280U, 0U, 59506691U, 0U, 7340556U, 0U, 131072U, 0U, 134250688U, 0U, 1618477104U, 0U, 6297600U, 0U, 3765443587U, 0U, 787328U, 0U, 0U, 0U, 2013265920U, 0U, 458752U, 0U, 3223322744U, 0U, 4026531841U, 0U, 202964991U, 0U, 471347200U, 0U, 12582912U, 0U, 1610612739U, 0U, 1611608064U, 0U, 33554432U, 0U, 3758882816U, 0U, 0U, 0U};
static int ng19[] = {9, 0};
static unsigned int ng20[] = {224U, 0U, 50593798U, 0U, 4294444940U, 0U, 262143U, 0U, 16892096U, 0U, 3225165872U, 0U, 2160072704U, 0U, 3224378371U, 0U, 1835392U, 0U, 0U, 0U, 805306368U, 0U, 458752U, 0U, 3764387888U, 0U, 1073741824U, 0U, 202424320U, 0U, 471343104U, 0U, 12582912U, 0U, 1610612739U, 0U, 4027461632U, 0U, 67108863U, 0U, 3758882816U, 0U, 0U, 0U};
static int ng21[] = {10, 0};
static unsigned int ng22[] = {128U, 0U, 101056518U, 0U, 7341580U, 0U, 393216U, 0U, 25280704U, 0U, 3223074864U, 0U, 3250588672U, 0U, 2149063681U, 0U, 3670401U, 0U, 0U, 0U, 0U, 0U, 458752U, 0U, 3762290688U, 0U, 2147483648U, 0U, 204587008U, 0U, 134234128U, 0U, 12582914U, 0U, 1610612739U, 0U, 2014195712U, 0U, 33554432U, 0U, 3758882816U, 0U, 1U, 0U};
static int ng23[] = {11, 0};
static unsigned int ng24[] = {1280U, 0U, 100859918U, 0U, 12584460U, 0U, 395270U, 0U, 12681408U, 0U, 2148282416U, 0U, 3246392321U, 0U, 2149063681U, 0U, 3670147U, 0U, 0U, 0U, 0U, 0U, 458752U, 0U, 1883242496U, 0U, 2147483648U, 0U, 203538432U, 0U, 16432U, 0U, 8388610U, 0U, 1612709891U, 0U, 3222155392U, 0U, 100663296U, 0U, 1611399936U, 0U, 3U, 0U};
static int ng25[] = {12, 0};
static unsigned int ng26[] = {3584U, 0U, 201555982U, 0U, 2155873804U, 0U, 919047U, 0U, 14876864U, 0U, 12336U, 0U, 3279946755U, 0U, 2149325825U, 0U, 3670147U, 0U, 0U, 0U, 0U, 0U, 458752U, 0U, 1887436800U, 0U, 0U, 0U, 203423744U, 0U, 4294967288U, 0U, 7U, 0U, 4294443392U, 0U, 2147889407U, 0U, 100663297U, 0U, 2147483520U, 0U, 6U, 0U};
static int ng27[] = {13, 0};
static unsigned int ng28[] = {4294967040U, 0U, 402767873U, 0U, 16778780U, 0U, 919431U, 0U, 14811328U, 0U, 12336U, 0U, 3279945731U, 0U, 793601U, 0U, 3670019U, 0U, 0U, 0U, 0U, 0U, 458752U, 0U, 813694976U, 0U, 0U, 0U, 205520902U, 0U, 112U, 0U, 131078U, 0U, 1613758688U, 0U, 405696U, 0U, 234881025U, 0U, 1611399168U, 0U, 12U, 0U};
static int ng29[] = {14, 0};
static unsigned int ng30[] = {7340032U, 0U, 268496896U, 0U, 1560U, 0U, 806093703U, 0U, 4331712U, 0U, 4206640U, 0U, 3271557127U, 0U, 793601U, 0U, 3932163U, 0U, 0U, 0U, 805322752U, 0U, 458752U, 0U, 964689968U, 0U, 0U, 0U, 205537279U, 0U, 96U, 0U, 805797894U, 0U, 1613758576U, 0U, 405696U, 0U, 201326594U, 0U, 1611399168U, 0U, 8U, 0U};
static int ng31[] = {15, 0};
static unsigned int ng32[] = {14680064U, 0U, 537099264U, 0U, 1560U, 0U, 2013266375U, 0U, 277696U, 0U, 4292882480U, 0U, 3338665989U, 0U, 924673U, 0U, 1966087U, 0U, 1067417600U, 0U, 4027041728U, 0U, 458767U, 0U, 956305392U, 0U, 0U, 0U, 205520896U, 0U, 128U, 0U, 1073709070U, 0U, 1613758513U, 0U, 3221631168U, 0U, 0U, 0U, 1611399680U, 0U, 16U, 0U};
static int ng33[] = {16, 0};
static unsigned int ng34[] = {25174016U, 0U, 1610592256U, 0U, 1560U, 0U, 4227858823U, 0U, 536870655U, 0U, 2154836016U, 0U, 2264924169U, 0U, 924675U, 0U, 2031623U, 0U, 252051456U, 0U, 1879165152U, 0U, 458752U, 0U, 520093808U, 0U, 0U, 0U, 203423744U, 0U, 6400U, 0U, 805502990U, 0U, 1613758514U, 0U, 3758502080U, 0U, 1U, 0U, 2147483392U, 0U, 32U, 0U};
static int ng35[] = {17, 0};
static unsigned int ng36[] = {50337792U, 0U, 2382364672U, 0U, 3608U, 0U, 2147516551U, 0U, 786625U, 0U, 2153787440U, 0U, 117440537U, 0U, 924675U, 0U, 1032199U, 0U, 117702656U, 0U, 1879167072U, 0U, 458752U, 0U, 503316592U, 0U, 0U, 0U, 202375168U, 0U, 4294965248U, 0U, 805503004U, 0U, 1613762562U, 0U, 4026937536U, 0U, 268435455U, 0U, 1611399168U, 0U, 0U, 0U};
static int ng37[] = {18, 0};
static unsigned int ng38[] = {100670464U, 0U, 0U, 0U, 3097U, 0U, 2147508231U, 0U, 786625U, 0U, 2162176048U, 0U, 117440545U, 0U, 924686U, 0U, 258055U, 0U, 118226944U, 0U, 1879171184U, 0U, 458752U, 0U, 234881136U, 0U, 1073741824U, 0U, 202899456U, 0U, 1073757184U, 0U, 805502976U, 0U, 1613761538U, 0U, 405696U, 0U, 6144U, 0U, 1611399168U, 0U, 0U, 0U};
static int ng39[] = {19, 0};
static unsigned int ng40[] = {402656768U, 0U, 0U, 0U, 3099U, 0U, 2147514374U, 0U, 786625U, 0U, 2162176048U, 0U, 117440513U, 0U, 925692U, 0U, 64519U, 0U, 60293120U, 0U, 1879162992U, 0U, 458752U, 0U, 234881136U, 0U, 3758096384U, 0U, 202113024U, 0U, 28672U, 0U, 805502976U, 0U, 1613760004U, 0U, 405696U, 0U, 6144U, 0U, 1611399296U, 0U, 0U, 0U};
static int ng41[] = {20, 0};
static unsigned int ng42[] = {4026533632U, 0U, 2164310016U, 0U, 4095U, 0U, 2147499014U, 0U, 786625U, 0U, 2162176048U, 0U, 117440513U, 0U, 924672U, 0U, 16135U, 0U, 59768832U, 0U, 1879162992U, 0U, 458752U, 0U, 251658352U, 0U, 4034920384U, 0U, 202178559U, 0U, 49152U, 0U, 805765120U, 0U, 1613760260U, 0U, 405696U, 0U, 6144U, 0U, 1611399616U, 0U, 0U, 0U};
static int ng43[] = {21, 0};
static unsigned int ng44[] = {2147483392U, 0U, 562094080U, 0U, 1027U, 0U, 2147490822U, 0U, 799169U, 0U, 2162176048U, 0U, 117440513U, 0U, 924672U, 0U, 3975U, 0U, 32505856U, 0U, 1879162992U, 0U, 458752U, 0U, 251658352U, 0U, 0U, 0U, 201721392U, 0U, 196608U, 0U, 805765120U, 0U, 1613759368U, 0U, 405696U, 0U, 6144U, 0U, 2147483616U, 0U, 0U, 0U};
static int ng45[] = {22, 0};
static unsigned int ng46[] = {2113929984U, 0U, 276881408U, 0U, 3U, 0U, 2147490822U, 0U, 268433857U, 0U, 2160078896U, 0U, 117440513U, 0U, 924672U, 0U, 1927U, 0U, 31457280U, 0U, 1879162992U, 0U, 458752U, 0U, 192938096U, 0U, 0U, 0U, 201721392U, 0U, 1441792U, 0U, 805765120U, 0U, 1613759240U, 0U, 405696U, 0U, 6144U, 0U, 1611661312U, 0U, 0U, 0U};
static int ng47[] = {23, 0};
static unsigned int ng48[] = {1573632U, 0U, 281067520U, 0U, 3145731U, 0U, 2147485710U, 0U, 786817U, 0U, 2160078896U, 0U, 117440513U, 0U, 924672U, 0U, 967U, 0U, 14680064U, 0U, 1879162992U, 0U, 458752U, 0U, 327155824U, 0U, 0U, 0U, 201721392U, 0U, 1835040U, 0U, 805699584U, 0U, 1613758488U, 0U, 929984U, 0U, 6144U, 0U, 1612447744U, 0U, 0U, 0U};
static int ng49[] = {24, 0};
static unsigned int ng50[] = {1835008U, 0U, 417447936U, 0U, 7864323U, 0U, 2147483662U, 0U, 786817U, 0U, 2160078896U, 0U, 117440513U, 0U, 793600U, 0U, 451U, 0U, 15728640U, 0U, 1879162992U, 0U, 458752U, 0U, 331350128U, 0U, 0U, 0U, 201721392U, 0U, 1835120U, 0U, 805699584U, 0U, 1613758480U, 0U, 929984U, 0U, 6144U, 0U, 1572880U, 0U, 0U, 0U};
static int ng51[] = {25, 0};
static unsigned int ng52[] = {1572864U, 0U, 409042944U, 0U, 4294705167U, 0U, 2149580799U, 0U, 17629569U, 0U, 2411737136U, 0U, 58721281U, 0U, 2148277248U, 0U, 2097603U, 0U, 15728640U, 0U, 1879162992U, 0U, 458752U, 0U, 566231152U, 0U, 0U, 0U, 219022896U, 0U, 4294967288U, 0U, 814088255U, 0U, 1613758512U, 0U, 942272U, 0U, 6144U, 0U, 1572920U, 0U, 0U, 0U};
static int ng53[] = {26, 0};
static unsigned int ng54[] = {1574400U, 0U, 208764928U, 0U, 502U, 0U, 2147483660U, 0U, 63734145U, 0U, 2273583152U, 0U, 58721281U, 0U, 2149325824U, 0U, 2097603U, 0U, 20447232U, 0U, 1879162992U, 0U, 458752U, 0U, 568328304U, 0U, 0U, 0U, 217845296U, 0U, 1835008U, 0U, 813563928U, 0U, 1613758496U, 0U, 549056U, 0U, 6144U, 0U, 4294967292U, 0U, 63U, 0U};
static int ng55[] = {27, 0};
static unsigned int ng56[] = {1576704U, 0U, 208732160U, 0U, 16134U, 0U, 2147483676U, 0U, 59564417U, 0U, 2198077488U, 0U, 58722305U, 0U, 2149325824U, 0U, 3146177U, 0U, 54001664U, 0U, 1879162992U, 0U, 458752U, 0U, 1625292912U, 0U, 268435456U, 0U, 204999728U, 0U, 1835008U, 0U, 807149568U, 0U, 1613758560U, 0U, 24768U, 0U, 6144U, 0U, 16318464U, 0U, 0U, 0U};
static int ng57[] = {28, 0};
static unsigned int ng58[] = {4294967168U, 0U, 208863232U, 0U, 14342U, 0U, 2147483676U, 0U, 51147521U, 0U, 2147745840U, 0U, 25167873U, 0U, 2149063680U, 0U, 1049025U, 0U, 35389440U, 0U, 1879162992U, 0U, 458752U, 0U, 1088422000U, 0U, 268435456U, 0U, 203426864U, 0U, 1835008U, 0U, 805834752U, 0U, 1676675040U, 0U, 49344U, 0U, 6144U, 0U, 31031296U, 0U, 0U, 0U};
static int ng59[] = {29, 0};
static unsigned int ng60[] = {1572864U, 0U, 207749120U, 0U, 2147487750U, 0U, 2147483707U, 0U, 101462785U, 0U, 2147745840U, 0U, 29364225U, 0U, 3224378368U, 0U, 1573760U, 0U, 69074944U, 0U, 1879162992U, 0U, 458752U, 0U, 3228565616U, 0U, 268435456U, 0U, 201333808U, 0U, 1835008U, 0U, 805310464U, 0U, 1625293248U, 0U, 49344U, 0U, 6144U, 0U, 60342272U, 0U, 0U, 0U};
static int ng61[] = {30, 0};
static unsigned int ng62[] = {1572864U, 0U, 201457664U, 0U, 4026531846U, 0U, 2147483760U, 0U, 101462529U, 0U, 2147745840U, 0U, 14692353U, 0U, 1617959936U, 0U, 1835776U, 0U, 202244096U, 0U, 1879162992U, 0U, 458752U, 0U, 2154823792U, 0U, 268435456U, 0U, 201332784U, 0U, 1835008U, 0U, 805318656U, 0U, 1623195840U, 0U, 98432U, 0U, 6144U, 0U, 102260736U, 0U, 0U, 0U};
static int ng63[] = {31, 0};
static unsigned int ng64[] = {1572864U, 0U, 201719808U, 0U, 1040187398U, 0U, 2147483872U, 0U, 202122753U, 0U, 2147745840U, 0U, 7356417U, 0U, 817896448U, 0U, 1969664U, 0U, 470745088U, 0U, 1879162992U, 0U, 458752U, 0U, 2155348080U, 0U, 268435457U, 0U, 201340976U, 0U, 1835008U, 0U, 805318656U, 0U, 1610612928U, 0U, 98304U, 0U, 6144U, 0U, 471349248U, 0U, 0U, 0U};
static int ng65[] = {32, 0};
static unsigned int ng66[] = {1572864U, 0U, 262144U, 0U, 528482318U, 0U, 2147484096U, 0U, 135007233U, 0U, 2147876912U, 0U, 2064385U, 0U, 528514816U, 0U, 1178624U, 0U, 2118107136U, 0U, 4287099388U, 0U, 2164258831U, 0U, 3774746623U, 0U, 268435463U, 0U, 201355312U, 0U, 1835008U, 0U, 805320704U, 0U, 1610612928U, 0U, 196608U, 0U, 6144U, 0U, 941104128U, 0U, 0U, 0U};
static int ng67[] = {33, 0};
static unsigned int ng68[] = {1572912U, 0U, 266240U, 0U, 130024348U, 0U, 2147484544U, 0U, 270272513U, 0U, 2148466800U, 0U, 1U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 939524096U, 0U, 201383992U, 0U, 1835008U, 0U, 939554816U, 0U, 1610612928U, 0U, 131072U, 0U, 931840U, 0U, 3759673216U, 0U, 0U, 0U};
static int ng69[] = {34, 0};
static unsigned int ng70[] = {1572984U, 0U, 538624U, 0U, 62914812U, 0U, 2147487232U, 0U, 553390081U, 0U, 4294840304U, 0U, 1U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 4160749568U, 0U, 201424927U, 0U, 66846720U, 0U, 536866816U, 0U, 1610612928U, 0U, 262144U, 0U, 260096U, 0U, 2149057532U, 0U, 1U, 0U};
static int ng71[] = {35, 0};
static unsigned int ng72[] = {4294967292U, 0U, 4294966303U, 0U, 29360248U, 0U, 2147514368U, 0U, 3678209U, 0U, 2146960352U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 4026531840U, 0U, 201523231U, 0U, 16252928U, 0U, 0U, 0U, 1610612928U, 0U, 524288U, 0U, 61440U, 0U, 1573112U, 0U, 6U, 0U};
static int ng73[] = {36, 0};
static unsigned int ng74[] = {0U, 0U, 0U, 0U, 12582944U, 0U, 2147729408U, 0U, 3162115U, 0U, 192U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 203161600U, 0U, 7340032U, 0U, 0U, 0U, 1610612928U, 0U, 1048576U, 0U, 28672U, 0U, 1572912U, 0U, 24U, 0U};
static int ng75[] = {37, 0};
static unsigned int ng76[] = {0U, 0U, 0U, 0U, 0U, 0U, 1835008U, 0U, 32770U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 134217728U, 0U, 2097152U, 0U, 0U, 0U, 1073741824U, 0U, 2097152U, 0U, 16384U, 0U, 1048576U, 0U, 32U, 0U};
static int ng77[] = {38, 0};
static int ng78[] = {39, 0};



static int sp_Word_Choose(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(13, ng0);

LAB5:    xsi_set_current_line(14, ng0);
    t5 = (t1 + 2040);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);

LAB6:    t8 = ((char*)((ng1)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t8, 32);
    if (t9 == 1)
        goto LAB7;

LAB8:    t4 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB9;

LAB10:    t4 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB11;

LAB12:    t4 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB13;

LAB14:    t4 = ((char*)((ng9)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB15;

LAB16:    t4 = ((char*)((ng11)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB17;

LAB18:    t4 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB19;

LAB20:    t4 = ((char*)((ng15)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB21;

LAB22:    t4 = ((char*)((ng17)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB23;

LAB24:    t4 = ((char*)((ng19)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB25;

LAB26:    t4 = ((char*)((ng21)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB27;

LAB28:    t4 = ((char*)((ng23)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB29;

LAB30:    t4 = ((char*)((ng25)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB31;

LAB32:    t4 = ((char*)((ng27)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB33;

LAB34:    t4 = ((char*)((ng29)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB35;

LAB36:    t4 = ((char*)((ng31)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB37;

LAB38:    t4 = ((char*)((ng33)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB39;

LAB40:    t4 = ((char*)((ng35)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB41;

LAB42:    t4 = ((char*)((ng37)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB43;

LAB44:    t4 = ((char*)((ng39)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB45;

LAB46:    t4 = ((char*)((ng41)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB47;

LAB48:    t4 = ((char*)((ng43)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB49;

LAB50:    t4 = ((char*)((ng45)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB51;

LAB52:    t4 = ((char*)((ng47)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB53;

LAB54:    t4 = ((char*)((ng49)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB55;

LAB56:    t4 = ((char*)((ng51)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB57;

LAB58:    t4 = ((char*)((ng53)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB59;

LAB60:    t4 = ((char*)((ng55)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB61;

LAB62:    t4 = ((char*)((ng57)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB63;

LAB64:    t4 = ((char*)((ng59)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB65;

LAB66:    t4 = ((char*)((ng61)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB67;

LAB68:    t4 = ((char*)((ng63)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB69;

LAB70:    t4 = ((char*)((ng65)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB71;

LAB72:    t4 = ((char*)((ng67)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB73;

LAB74:    t4 = ((char*)((ng69)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB75;

LAB76:    t4 = ((char*)((ng71)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB77;

LAB78:    t4 = ((char*)((ng73)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB79;

LAB80:    t4 = ((char*)((ng75)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB81;

LAB82:    t4 = ((char*)((ng77)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB83;

LAB84:    t4 = ((char*)((ng78)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 6, t4, 32);
    if (t9 == 1)
        goto LAB85;

LAB86:
LAB87:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    xsi_set_current_line(15, ng0);
    t10 = ((char*)((ng2)));
    t11 = (t1 + 1880);
    xsi_vlogvar_assign_value(t11, t10, 0, 0, 680);
    goto LAB87;

LAB9:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng4)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB11:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng6)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB13:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng8)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB15:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng10)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB17:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng12)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB19:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng14)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB21:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng16)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB23:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng18)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB25:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng20)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB27:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng22)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB29:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng24)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB31:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng26)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB33:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng28)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB35:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng30)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB37:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng32)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB39:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng34)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB41:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng36)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB43:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng38)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB45:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng40)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB47:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng42)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB49:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng44)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB51:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng46)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB53:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng48)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB55:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng50)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB57:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng52)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB59:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng54)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB61:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng56)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB63:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng58)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB65:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng60)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB67:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng62)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB69:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng64)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB71:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng66)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB73:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng68)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB75:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng70)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB77:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng72)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB79:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng74)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB81:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng76)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB83:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng2)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

LAB85:    xsi_set_current_line(15, ng0);
    t5 = ((char*)((ng2)));
    t6 = (t1 + 1880);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 680);
    goto LAB87;

}

static void Always_7_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    t1 = (t0 + 2960U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(7, ng0);
    t2 = (t0 + 3280);
    *((int *)t2) = 1;
    t3 = (t0 + 2992);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(7, ng0);

LAB5:    xsi_set_current_line(8, ng0);
    t4 = (t0 + 1480U);
    t5 = *((char **)t4);
    t4 = (t0 + 2768);
    t6 = (t0 + 848);
    t7 = xsi_create_subprogram_invocation(t4, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t7);
    t8 = (t0 + 2040);
    xsi_vlogvar_assign_value(t8, t5, 0, 0, 6);

LAB8:    t9 = (t0 + 2864);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t13 = (t12 + 272U);
    t14 = *((char **)t13);
    t15 = (t14 + 0U);
    t16 = *((char **)t15);
    t17 = ((int  (*)(char *, char *))t16)(t0, t10);

LAB10:    if (t17 != 0)
        goto LAB11;

LAB6:    t10 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t10);

LAB7:    t18 = (t0 + 2864);
    t19 = *((char **)t18);
    t18 = (t0 + 848);
    t20 = (t0 + 2768);
    t21 = 0;
    xsi_delete_subprogram_invocation(t18, t19, t0, t20, t21);
    goto LAB2;

LAB9:;
LAB11:    t9 = (t0 + 2960U);
    *((char **)t9) = &&LAB8;
    goto LAB1;

}


extern void work_m_00000000001307196216_3454374500_init()
{
	static char *pe[] = {(void *)Always_7_0};
	static char *se[] = {(void *)sp_Word_Choose};
	xsi_register_didat("work_m_00000000001307196216_3454374500", "isim/t1_isim_beh.exe.sim/work/m_00000000001307196216_3454374500.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
