#include "lbf.h"		//调用自定义头文件

PHONE *backspace(PHONE *p1)	//删除函数
{
	int ch = 0;

	int i = 0;

	int j = 0;

	PHONE *p2 = p1;

	PHONE *p3 = p1->next;	//保存第一个含有信息的节点

	if(p3)
	{	
		i = display(p1);	//调用遍历函数

		printf("\n");

		printf("请输入编号:");

		while(1)		//死循环
		{		

			if(scanf("%d", &ch) == 1)	//如果输入的是数字
			{

				break;

			}
			else
			{

				fflush(stdin);		//清空缓冲区

				ch = 0;

			}
		}

		if(ch > i || ch <= 0)
		{

			printf("超出范围, ");

		}

		else
		{
			printf("%d", i);

			while(p2->next)	//循环到链表尾
			{

				if(++j == ch)
				{

					break;	//退出循环

				}

				p3 = p3->next;	//节点进位

				p2 = p2->next;	//节点进位

			}

			p2->next = p3->next;

			free(p3);		//释放空间

			printf("删除成功, ");

		}


	}


	else
	{

		printf("通讯录内不存在成员\n");

	}
	
	return p1;
}
