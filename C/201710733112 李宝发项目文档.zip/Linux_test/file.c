#include "lbf.h"		//调用自定义头文件

void file_write(PHONE *p1)	//写文件函数
{
	FILE *fp = NULL;
	PHONE *p2 = p1;

	fp = fopen("phone.txt", "w");	//以只读方式打开文件
	
	while(p2)
	{
		fprintf(fp, "%s\t%s\t%s\n", p2->data.phone, p2->data.relation, p2->data.name);	//向文件内写内容
		p2 = p2->next;	//节点进位
	}

	fclose(fp);		//关闭文件
}

PHONE *file_read()		//读文件函数
{
	FILE *fp = NULL;

	PHONE *p1 = (PHONE *)malloc(sizeof(PHONE));	//开辟空间

	PHONE *p2 = NULL;

	PHONE *p3 = NULL;

	p1->next = NULL;

	p2 = p1;
	
	fp = fopen("phone.txt", "r");		//以只读方式打开文件

	if(fp)
	{		
		while(!feof(fp))		//如果没有读到文件尾
		{	
			p3 = (PHONE *)malloc(sizeof(PHONE));	//开辟空间

			p3->next = NULL;

			if(feof(fp))		//如果读到文件尾
			{

				free(p3);	//释放空间

				break;		//退出循环

			}
			fscanf(fp, "%s\t%s\t%s\n", p3->data.phone, p3->data.relation, p3->data.name);	//从文件中读取数据到变量

			p2->next = p3;

			p2 = p2->next;

		}	
	}
	else
	{

		fp = fopen("phone.txt", "w");	//以只写方式打开文件

	}

	fclose(fp);		//关闭文件

	return p1;
}
