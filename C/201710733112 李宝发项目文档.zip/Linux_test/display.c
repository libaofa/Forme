#include "lbf.h"		//调用自定义头文件

int display(PHONE *p1)		//遍历函数
{
	int i = 0;

	PHONE *p2 = p1->next;

	if(p2)		//如果含有节点

	{	
		printf("************************************");

		printf("*************************************\n");

		printf("*\t编号\t\t电话\t\t关系\t\t姓名\t\t*\n");

		printf("************************************");

		printf("*************************************\n");
	
		while(p2)	//循环到链表尾部
		{
			printf("*\t%d\t\t", ++i);

			printf("%s\t", p2->data.phone);

			printf("%s\t\t", p2->data.relation);

			printf("%s\t\t*\n", p2->data.name);

			printf("************************************");

			printf("*************************************\n");

			p2 = p2->next;	//节点进位
		}
	}
	else
	{

		printf("通讯录内不存在成员, ");

	}

	return i;	//返回节点数
}
