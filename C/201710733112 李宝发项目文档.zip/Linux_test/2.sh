#!/bin/bash

make clean
