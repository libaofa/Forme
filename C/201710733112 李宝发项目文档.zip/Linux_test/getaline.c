#include "lbf.h"		//调用自定义头文件

void getaline(char data[], int size)	//调用字符串函数
{
	int ch = 0;

	int i = 0;

	rewind(stdin);		//清空缓冲区

	while (1)
	{
		ch = getchar();		//输入一个字符

		if (ch == '\n')
		{		

			break;		//退出循环

		}
		else if(ch == ' ' || ch == '\t')
		{

			continue;	//进行下一次循环

		}
		else
		{
			if (i < size)
			{

				data[i++] = ch;	//将字符存在数组中

			}
		}
	}
	data[i] = '\0';
}
