#ifndef _LBF_H
#define _LBF_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct Data		
{
	char name[21];		//姓名
	char phone[12];		//电话号	
	char relation[10];	//关系
}DATA;

typedef struct Phone 		
{
	DATA data;		//数据
	struct Phone *next;	//指针
}PHONE;

void getaline(char [], int );		//自定义输入字符串函数
PHONE *menu();				//菜单函数
PHONE *insert(PHONE *, int , int );	//添加或修改函数
int display(PHONE *);			//遍历函数	
void query(PHONE *);			//查找函数
PHONE *backspace(PHONE *);		//删除函数
PHONE *modify(PHONE *);			//修改函数
void file_write(PHONE *);		//写文件函数
PHONE *file_read();			//读文件函数

#endif

