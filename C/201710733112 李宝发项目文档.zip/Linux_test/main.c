#include "lbf.h"		//调用自定义头文件

int main()
{
	PHONE *p1 = NULL;

	PHONE *p2 = NULL;

	PHONE *p3 = NULL;

	p1 = menu();		//调用菜单函数

	p2 = p1;

	p3 = p1->next;

	while(p2->next)		//循环运行到链表尾部
	{
		p2->next = p3->next;	//p2进位

		free(p3);		//释放便空间

		p3 = p2->next;		//p3保存p2的后一个节点
	}

	free(p1);		//释放头节点
	
	return 0;
}
