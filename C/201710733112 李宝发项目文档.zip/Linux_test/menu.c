#include "lbf.h"		//调用自定义头文件

PHONE *menu()			//菜单函数
{
	int ch = 0;

	int i = 0;

	PHONE *p1 = NULL;

	p1 = file_read();	//调用写文件函数

	while(1)		//死循环
	{

		system("clear");	//清屏函数

		printf("		*************************\n");

		printf("		*	1.添加		*\n");

		printf("		*************************\n");

		printf("		*	2.查询		*\n");

		printf("		*************************\n");

		printf("		*	3.遍历		*\n");

		printf("		*************************\n");

		printf("		*	4.删除		*\n");

		printf("		*************************\n");

		printf("		*	5.修改		*\n");

		printf("		*************************\n");

		printf("		*	6.退出		*\n");

		printf("		*************************\n");

		printf("\n请键入您的选择:");

		ch = getchar();		//输入一个字符

		system("clear");	//清屏函数

		switch(ch)		//多分支选择语句
		{
			case '1':
				p1 = insert(p1, 0, 0);		//调用添加修改函数
				break;

			case '2':
				query(p1);		//调用查找函数
				break;

			case '3':
				i = display(p1);	//调用遍历函数
				break;

			case '4':
				p1 = backspace(p1);	//调用删除函数
				break;

			case '5':
				p1 = modify(p1);	//调用修改函数
				break;

			case '6':
				return p1;		//返回主函数

			default:			//其他情况
				printf("请输入1～5的数字\n");
				break;

		}
		file_write(p1->next);	//调用写文件函数

		printf("按Enter键继续\n");

		getchar();		//暂停
		getchar();
	}
}
