#include "lbf.h"		//调用自定义头文件

PHONE *insert(PHONE *p1, int m, int count)	//添加或修改函数
{
	int ch = 0;

	int i = 0;

	int j = 0;

	int flag = 1;

	static char relation_i;

	const char relation_1[9] = "亲__人";

	const char relation_2[9] = "朋__友";

	const char relation_3[9] = "陌生人";

	PHONE *p2 = p1;

	PHONE *p3 = (PHONE *)malloc(sizeof(PHONE));	//开辟空间

	getchar();		//获取一个字符

	printf("请输入姓名:");

	getaline(p3->data.name,20);	//调用字符串输入函数

	while(flag)
	{
		printf("请输入电话号:");

		getaline(p3->data.phone,11);	//调用字符串输入函数+

		if(strlen(p3->data.phone) != 11)	//判断字符串字节
		{

			printf("电话号须为11位数字\n");

		}
		else
		{

			if(p3->data.phone[0] != '0' && p3->data.phone[0] != '1')	//判断字符串首位
			{

				printf("首位必须是1或者0\n");

			}
			else
			{
				for(i = 0; i < 11; i++)	//for循环
				{

					if(p3->data.phone[i] < '0' || p3->data.phone[i] > '9')		
					{

						flag = 1;

						printf("电话号必须为纯数字\n");

						break;	//退出循环

					}	
					else 
					{

						flag = 0;

					}
				}
			}
		}
	}

	printf("1.亲__人\n");
	printf("2.朋__友\n");
	printf("3.陌生人\n");

	while(1)		//死循环
	{
		printf("请选择关系:");
		relation_i = getchar();	//输入一个字符

		if(relation_i >= '1' && relation_i <= '3')
		{
			break;
		}
	}
	if(relation_i == '1')
	{
		strcpy(p3->data.relation, relation_1);	//字符串拷贝
	}
	else if(relation_i == '2')
	{
		strcpy(p3->data.relation, relation_2);	//字符串拷贝
	}
	else if(relation_i == '3')
	{
		strcpy(p3->data.relation, relation_3);	//字符串拷贝
	}		
	if(m == 0)
	{
		while(p2->next)
		{
			p2 = p2->next;		//节点进位
		}

		p2->next = p3;
		p3->next = NULL;
		printf("\n添加成功, ");
	}
	else
	{
		while(p2)
		{
			if(j++ == count)
			{
				break;	//退出循环
			}

			p2 = p2->next;
		}

		strcpy(p2->data.name, p3->data.name);	//字符串拷贝函数
		strcpy(p2->data.phone, p3->data.phone);	//字符串拷贝函数
		strcpy(p2->data.relation, p3->data.relation);	//字符串拷贝函数
		free(p3);		//释放空间
		printf("\n修改成功, ");
	}

	return p1;
}
