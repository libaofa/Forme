#include "lbf.h"		//调用自定义头文件

PHONE *modify(PHONE *p1)	//修改函数
{
	int ch = 0;

	int i = 0;

	int j = 0;

	PHONE *p2 = p1->next;

	if(p2)
	{	
		i = display(p1);		//调用遍历函数

		printf("请输入编号:");

		while(1)
		{
			if(scanf("%d", &ch) == 1)	//如果输入的是数字
			{

				break;

			}
			else
			{
				fflush(stdin);	//清空缓冲区

				ch = 0;
			}
		}
		if(ch > i || ch <= 0)
		{

			printf("超出范围, ");

		}
		else
		{

			p1 = insert(p1, 1, ch);		//调用添加或修改函数

		}
	}
	else
	{

		printf("通讯录内不存在成员, ");

	}
	
	return p1;
}
