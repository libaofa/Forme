#!/bin/bash

make
./phone
