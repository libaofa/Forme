#include <stdio.h>
#include "sqlite3.h"
#include "lbf.h"

int main(int argc, char* argv[])
{
	sqlite3 *db = NULL;
	home(db);

	return 0;
}